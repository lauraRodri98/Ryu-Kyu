package Ryukyu;

public class Interfaz{

    public static void mostrarPuntuaciones()
    {
        System.out.println("                   _____________________________________________________");
        System.out.println("                  |                                                     |");
        System.out.println("                  |        ~ ~ ~ ~      PUNTUACIONES      ~ ~ ~ ~       |");
        System.out.println("                  |                                                     |");
        System.out.println("                  |     1PR - 200        STR - 1000       4K - 2000     |");
        System.out.println("                  |                                                     |");
        System.out.println("                  |     2P2 - 400        FL  - 1400       SF - 2400     |");
        System.out.println("                  |                                                     |");
        System.out.println("                  |     3K  - 800        FH  - 1800       RF - 2800     |");
        System.out.println("                  |_____________________________________________________|");
        System.out.println();        
        System.out.println("                            *****        PUNTUACION         *****        ");
        System.out.println();        

    }

    public static void mostrarMontonCartas (int montonCartas[], int columnas, int filas)
    {//Arreglar que cada vez que elija una columna espeecifica solo le quite valor a esa columna
        //Controla los espacion segun las columnas selecionadas para los mostones de cartas
        String espacioMatrizJuego = "                                  ";  
        String espacioPequeño = "      ";                            
        String espacio1 = "          ";
        String espacio2 = "        ";
        String espacio3 = "    ";
        String espacio4 = "  ";

        int[]montonActualizado =IniciarJuego.actualizarMontonCartas(montonCartas);

        if(columnas == 1)
        {
            System.out.print(espacioMatrizJuego + espacio1);
            imprimirMontonCartas(montonActualizado, columnas, filas);
            System.out.println(espacioMatrizJuego + "          \u2193   ");
        }

        if(columnas == 2)
        {
            System.out.print(espacioMatrizJuego + espacio2);
            imprimirMontonCartas(montonActualizado, columnas, filas);

            System.out.print(espacioMatrizJuego + espacio2 + espacioPequeño);
            imprimirMontonCartas(montonActualizado, columnas, filas);
            System.out.println(espacioMatrizJuego + "        \u2193   " + "  \u2193  ");
        }

        if(columnas == 3)
        {
            System.out.print(espacioMatrizJuego  +espacio3);
            imprimirMontonCartas(montonActualizado, columnas, filas);

            System.out.print(espacioMatrizJuego + espacio3 + espacioPequeño);
            imprimirMontonCartas(montonActualizado, columnas, filas);

            System.out.print(espacioMatrizJuego + espacio3 + espacioPequeño + espacioPequeño);
            imprimirMontonCartas(montonActualizado, columnas, filas);
            System.out.println(espacioMatrizJuego + "    \u2193   " + "  \u2193  " + "   \u2193  ");
        }

        if(columnas == 4)
        {
            System.out.print(espacioMatrizJuego + espacio4);
            imprimirMontonCartas(montonActualizado, columnas, filas);

            System.out.print(espacioMatrizJuego + espacio4 + espacioPequeño);
            imprimirMontonCartas(montonActualizado, columnas, filas);

            System.out.print(espacioMatrizJuego + espacio4 + espacioPequeño + espacioPequeño);
            imprimirMontonCartas(montonActualizado, columnas, filas);

            System.out.print(espacioMatrizJuego + espacio4 + espacioPequeño + espacioPequeño + espacioPequeño);
            imprimirMontonCartas(montonActualizado, columnas, filas);
            System.out.println(espacioMatrizJuego + " \u2193   " + "  \u2193  " + "   \u2193   " + "  \u2193");
        }
    }

    public static void imprimirMontonCartas(int [] matrizMonton, int columnas, int filas) 
    //Muestra simbolo en funcion de la longitu del monton carta
    {      
        Character elemento = '\u25A9'; 

        for (int i=0; i < matrizMonton.length; i++) 
        {
            System.out.print(elemento + "|");
        }
        System.out.println();
    }
    

    public static void mostrarMontonElegir(int columnas, int filas, int [][] matrizElegir)
    {
        //Regula los espacios, que dependen de las columnas elegidas y muestra las cartas

        String espacioMatrizJuego = "                               ";                              
        String espacio1 = "          ";
        String espacio2 = "       ";
        String espacio3 = "    ";
        String espacio4 = " ";

        switch (columnas)
        {
            case 1:
                espacioMatrizJuego = espacioMatrizJuego + espacio1;
                System.out.println(espacioMatrizJuego + "-------");
                break;
            case 2:
                espacioMatrizJuego = espacioMatrizJuego + espacio2;
                System.out.println(espacioMatrizJuego + "-------------");
                break;
            case 3:
                espacioMatrizJuego = espacioMatrizJuego + espacio3;
                System.out.println(espacioMatrizJuego + "-------------------");
                break;
            case 4:
                espacioMatrizJuego = espacioMatrizJuego + espacio4; 
                System.out.println(espacioMatrizJuego + "-------------------------");
                break;
        }                                        
        
        for(int i=0; i<filas;i++)
        {
            System.out.print(espacioMatrizJuego +"| ");
            for(int j=0; j<columnas; j++)
            {
                int carta = matrizElegir[i][j];
                Carta c = new Carta(carta);
                String mostrarCarta = c.toString();
                System.out.print(mostrarCarta + " | ");
            }
            System.out.println("");
        }
        
        switch (columnas)
        {
            case 1:
                
                System.out.println(espacioMatrizJuego + "-------");
                break;
            case 2:

                System.out.println(espacioMatrizJuego + "-------------");
                break;
            case 3:

                System.out.println(espacioMatrizJuego + "-------------------");
                break;
            case 4:

                System.out.println(espacioMatrizJuego + "-------------------------");
                break;
        } 
    }

    public static void imprimirMatrizVacia() 
    {
        //Matriz juego vacia

        String espacioMatrizJuego = "                            ";
        System.out.println(espacioMatrizJuego + "   \u2193   " + "   \u2193  " + "   \u2193  " + "   \u2193  " + "   \u2193");
        System.out.println(espacioMatrizJuego + "------------------------------");

        for (int i = 0; i < 5; i++) {
            System.out.print(espacioMatrizJuego + "|");
            for (int j = 0; j < 5; j++) {
                System.out.print("     |");
            }
            System.out.println("");
            System.out.println(espacioMatrizJuego + "------------------------------");
        }
    }

    public static void imprimirMatrizConCartas(int[][] matrizJuego) 
    {
        //Funcion que regula los espacios si tiene o no cartas

        String espacioMatrizJuego = "                             ";
        System.out.println(espacioMatrizJuego + "   \u2193   " + "  \u2193   " + "  \u2193   " + "  \u2193   " + "  \u2193");
        System.out.println(espacioMatrizJuego + "-------------------------------");

        for (int i = 0; i < 5; i++) {
            System.out.print(espacioMatrizJuego + "|");
            for (int j = 0; j < 5; j++) {
                int carta = matrizJuego[i][j];
                if (carta == 0) {
                    System.out.print("     |");
                } else {
                    Carta c = new Carta(carta);
                    String mostrarCarta = c.toString();
                    System.out.print(" " + mostrarCarta + " |");
                }
            }
            System.out.println("");
            System.out.println(espacioMatrizJuego + "-------------------------------");
        }
    }

}
