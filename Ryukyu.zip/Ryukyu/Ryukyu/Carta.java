package Ryukyu;

class Carta
{
    private int num;

    Carta()
    {
        num = 0;
    }

    public Carta(int num)
    {
        this.num = num;
    }

    public int getNum() 
    {
        return num;
    }

    public void setNum(int num) 
    {
        this.num = num;
    }

    public String toString()
    {
        String mostrar ="";

        switch (num)
        {
            //Las centanas nos dice que palo es la carta, unidades y decenas muestran el valor

            //cartas del 1 a la K (Pikas)
            case 101: mostrar = "A" + " \u2660"; break;
            case 102: mostrar = 2 + " \u2660"; break;
            case 103: mostrar = 3 + " \u2660"; break;
            case 104: mostrar = 4 + " \u2660"; break;
            case 105: mostrar = 5 + " \u2660"; break;
            case 106: mostrar = 6 + " \u2660"; break;
            case 107: mostrar = 7 + " \u2660"; break;
            case 108: mostrar = 8 + " \u2660"; break;
            case 109: mostrar = 9 + " \u2660"; break;
            case 110: mostrar = 10 + "\u2660"; break;
            case 111: mostrar = "J" + " \u2660"; break;
            case 112: mostrar = "Q" + " \u2660"; break;
            case 113: mostrar = "K" + " \u2660"; break;

            //cartas del 1 a la K (Corazones)
            case 201: mostrar = "A" +" \u2661"; break;
            case 202: mostrar = 2 + " \u2661"; break;
            case 203: mostrar = 3 + " \u2661"; break;
            case 204: mostrar = 4 + " \u2661"; break;
            case 205: mostrar = 5 + " \u2661"; break;
            case 206: mostrar = 6 + " \u2661"; break;
            case 207: mostrar = 7 + " \u2661"; break;
            case 208: mostrar = 8 + " \u2661"; break;
            case 209: mostrar = 9 + " \u2661"; break;
            case 210: mostrar =10 + "\u2661"; break;
            case 211: mostrar = "J" + " \u2661"; break;
            case 212: mostrar = "Q" + " \u2661"; break;
            case 213: mostrar = "K" + " \u2661"; break;

            //cartas del 1 a la K (Trebol)
            case 301: mostrar = "A"+ " \u2663"; break;
            case 302: mostrar = 2 + " \u2663"; break;
            case 303: mostrar = 3 + " \u2663"; break;
            case 304: mostrar = 4 + " \u2663"; break;
            case 305: mostrar = 5 + " \u2663"; break;
            case 306: mostrar = 6 + " \u2663"; break;
            case 307: mostrar = 7 + " \u2663"; break;
            case 308: mostrar = 8 + " \u2663"; break;
            case 309: mostrar = 9 + " \u2663"; break;
            case 310: mostrar =10 + "\u2663"; break;
            case 311: mostrar = "J" + " \u2663"; break;
            case 312: mostrar = "Q" + " \u2663"; break;
            case 313: mostrar = "K" + " \u2663"; break;
 
            //cartas del 1 a la K (Diamantes)
            case 401: mostrar = "A" + " \u2662"; break;
            case 402: mostrar = 2 + " \u2662"; break;
            case 403: mostrar = 3 + " \u2662"; break;
            case 404: mostrar = 4 + " \u2662"; break;
            case 405: mostrar = 5 + " \u2662"; break;
            case 406: mostrar = 6 + " \u2662"; break;
            case 407: mostrar = 7 + " \u2662"; break;
            case 408: mostrar = 8 + " \u2662"; break;
            case 409: mostrar = 9 + " \u2662"; break;
            case 410: mostrar = 10 + "\u2662"; break;
            case 411: mostrar = "J" + " \u2662"; break;
            case 412: mostrar = "Q" + " \u2662"; break;
            case 413: mostrar = "K" + " \u2662"; break;
        }
        return mostrar;      
    }



}