package Ryukyu;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class IniciarJuego {

    public static void Ryukyu(int filas, int columnas)
    {
        Scanner sc = new Scanner(System.in);

        //Inicializamos nuestras matrices y la baraja
        int longitudMontonCartas = IniciarJuego.calculaLongitud(columnas, filas);
        int montonCartas[] = new int [longitudMontonCartas]; 
        int matrizElegir[][] = new int[filas][columnas];
        int matrizJuego[][] = new int[5][5];
        Baraja baraja = new Baraja();
        int cartaElegida =    0;

        //Insertamos las cartas
        IniciarJuego.matrizElegir(matrizElegir, baraja);
        int salir = -1;
        
        do
        {
            for(int i=0; i < 25; i++)
            {
                Tools.limpiarPantalla();
                //Mostramos puntuaciones del poker y las matrices
                Interfaz.mostrarPuntuaciones();
                IniciarJuego.mostrarPuntuacionMano(matrizJuego);

                Interfaz.mostrarMontonCartas(montonCartas, columnas, filas);
                Interfaz.mostrarMontonElegir(columnas, filas, matrizElegir);
                
                Interfaz.imprimirMatrizConCartas(matrizJuego);
                //Preguntar al usuario por la carta y donde la inserta
                cartaElegida = IniciarJuego.elegirCarta(matrizElegir,columnas, montonCartas, baraja);
                
                IniciarJuego.introducirCarta(cartaElegida, matrizJuego);
                Interfaz.imprimirMatrizConCartas(matrizJuego);
            }

            System.out.println("");
            System.out.println("                            Su puntuación final es: " + Puntuacion.puntosTotal(matrizJuego) + " puntos");
            //Crear un archivo que mande el resultado de los puntos
            //Guardamos la puntuacion
            // int [] puntuacion = {Puntuacion.puntosTotal(matrizJuego)};
            BufferedWriter out = null;
            try 
            {
                String c = String.valueOf(Puntuacion.puntosTotal(matrizJuego));
                out = new BufferedWriter(new FileWriter("out.txt"));
                out.write(c); //Escribimos la puntutuacion
                
            } catch (IOException e) 
            {
                System.out.println(e);
            }
            finally{
                if(out != null)
                {
                    try {
                        out.close();
                    } catch (IOException e) {
                        System.out.println("Ne se ha cerrado correctamente");
                    }
                }
            }


            System.out.println("                            Para volver al menú inserte 0");
            salir = sc.nextInt();

        }while(salir !=0);
    }

    public static void mostrarPuntuacionMano(int[][]matrizJuego)
    {
        System.out.println("                  Puntos totales: " + Puntuacion.puntosTotal(matrizJuego) + "     ");
        System.out.print("");
    }

    public static int calculaLongitud (int columnas, int filas)
    {
        //Calcula la longitud de la matrizMonton en funcion del numero de columnas
        int restar = columnas * filas;
        int cartaRestantes = 52 - restar;
        int longiMatriz = cartaRestantes/columnas;

        return longiMatriz;
    }

    public static int [] actualizarMontonCartas(int[] matrizMonton) {
        if (matrizMonton.length > 0) 
        {
            int nuevaLongitud = matrizMonton.length - 1;
            int[] nuevoArray = new int[nuevaLongitud];
            System.arraycopy(matrizMonton, 1, nuevoArray, 0, nuevaLongitud);
            matrizMonton = nuevoArray;
        }

        return matrizMonton;
    }

    public static void matrizElegir (int [][] matrizElegir, Baraja baraja)
    { 
        //Llenamos nuestra matriz de cartas
        Carta carta;
        
        for (int i = 0; i < matrizElegir.length; i++) 
        {
            for (int j = 0; j < matrizElegir[0].length; j++) 
            {
                carta = baraja.robarCarta();
                matrizElegir[i][j] = carta.getNum();
            }
        }
    }

    public static void actualizarMatrizElegir(int[][] matrizJElegir,int columnaElegida, Baraja baraja)
    {
       //Funcion que baja las cartas de la matriz conforme se van eligiendo

        for (int i = matrizJElegir.length - 1; i >= 0; i--) {
            if (i == 0) {
                // Insertar una nueva carta en la primera celda
                Carta nuevaCarta = baraja.robarCarta(); 
                matrizJElegir[i][columnaElegida] = nuevaCarta.getNum();

            } else {
                matrizJElegir[i][columnaElegida] = matrizJElegir[i - 1][columnaElegida];// Mover la carta hacia abajo
            }
        }
    }

    public static int elegirCarta (int [][] matrizElegir, int columna, int []matrizMonton, Baraja baraja)
    { 
        //guarda la carta elegida en una variable y la pasa
        Scanner sc = new Scanner(System.in);
        int cartaElegida = 0;
        boolean columnaValida = false;
        int columnaElegida =0;

        do{
            System.out.println("                     Elija carta [1 - " + columna + "]");
            System.out.print("                     ");
            columnaElegida = sc.nextInt()-1;

            if(columnaElegida >= 0 && columnaElegida < matrizElegir[0].length) //Si está dentro del rango de la matriz
            {
                columnaValida = true;
                cartaElegida = matrizElegir[matrizElegir.length-1][columnaElegida];
                actualizarMatrizElegir(matrizElegir, columnaElegida, baraja);
                actualizarMontonCartas(matrizMonton);
            }
        }
        while(!columnaValida);

        return cartaElegida;
    }

    public static void introducirCarta (int carta, int [][] matrizJuego)
    {
        //Matriz donde insertaremos nuestras cartas en la matrizJuego
        Scanner sc = new Scanner(System.in);
        boolean columnaValida = false;
 
        do{
            System.out.println("                     Elija entre [1-5]");
            System.out.print("                     ");
            int columnaNueva = sc.nextInt() -1; //La tabla su posicio comiencza en 0
            if (columnaNueva >= 0 && columnaNueva < matrizJuego[0].length) 
            {
                if(matrizJuego[0][columnaNueva] == 0) //Si la primera posicion de la fila está vacía
                {
                    for (int fila = matrizJuego.length -1; fila >=0 ; fila--) 
                    {
                        if (matrizJuego[fila][columnaNueva] == 0) //Celda vacía introducimos carta
                        {
                            matrizJuego[fila][columnaNueva] = carta;
                            columnaValida = true;
                            break;
                        }
                    }
                }
            }
        }
        while(!columnaValida);        
    }
}


    




