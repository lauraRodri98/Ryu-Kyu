package Ryukyu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Baraja 
{
    private List <Carta> cartasNaipes;    

    Baraja()
    {
        cartasNaipes = new ArrayList<Carta>();

        //Introducimos las  picas
        for (int i = 101; i<= 113; i++) 
        {
            Carta carta = new Carta(i);
            cartasNaipes.add(carta);
        }

        //Introducimos las  corazones
        for(int i=201; i<=213; i++)
        {
            Carta carta = new Carta(i);
            cartasNaipes.add(carta);
        }

        //Introducimos las trebol
        for(int i=301; i<=313; i++)
        {
            Carta carta = new Carta(i);
            cartasNaipes.add(carta);
        }

        //Introducimos las diamantes
        for(int i=401; i<=413; i++)
        {
            Carta carta = new Carta(i);
            cartasNaipes.add(carta);
        }
    }

    public void mezclarBaraja()
    {
        Collections.shuffle(cartasNaipes);
    }

    public Carta robarCarta ()
    {
        //Robamos una carta y la quitamos de la baraja
        mezclarBaraja();
        Carta c = cartasNaipes.get(0);
        cartasNaipes.remove(0);
        
        return c;
    }
    
    public String mostrar(int num)
    {
        return cartasNaipes.get(num).toString();
    }
}
