package Ryukyu;

import java.util.Arrays;

public class Puntuacion{
    
    public static int puntosTotal(int matrizJuego[][])
    {
        int [] fila1 = new int [5];
        int [] fila2 = new int [5];
        int [] fila3 = new int [5];
        int [] fila4 = new int [5];
        int [] fila5 = new int [5];
                    
        for (int i = 0; i < matrizJuego[0].length; i++) {
        //Vamos añadiendo las filas a los nuevos arrays para pedirle los puntos de la mano
           fila1 [i] = matrizJuego[0][i];
           fila2 [i] = matrizJuego[1][i];
           fila3 [i] = matrizJuego[2][i];
           fila4 [i] = matrizJuego[3][i];
           fila5 [i] = matrizJuego[4][i];
        }

        int puntFila1 = puntos(fila1);
        int puntFila2 = puntos(fila2);
        int puntFila3 = puntos(fila3);
        int puntFila4 = puntos(fila4);
        int puntFila5 = puntos(fila5);

        int puntuacionFilas = puntFila1 + puntFila2 + puntFila3 + puntFila4 + puntFila5;

        //Vamos añadiendo las filas a los nuevos arrays para pedirle los puntos de la mano
        int[] columna1 = new int[5];
        int[] columna2 = new int[5];
        int[] columna3 = new int[5];
        int[] columna4 = new int[5];
        int[] columna5 = new int[5];

        
        for (int i = 0; i < matrizJuego.length; i++) {
            columna1[i] = matrizJuego[i][0];
            columna2[i] = matrizJuego[i][1];
            columna3[i] = matrizJuego[i][2];
            columna4[i] = matrizJuego[i][3];
            columna5[i] = matrizJuego[i][4];
        }

        int puntColumna1 = puntos(columna1);
        int puntColumna2 = puntos(columna2);
        int puntColumna3 = puntos(columna3);
        int puntColumna4 = puntos(columna4);
        int puntColumna5 = puntos(columna5);

        int puntuacionColumnas = puntColumna1 + puntColumna2 + puntColumna3 + puntColumna4 + puntColumna5;

        //Añadimos diagonal y le pedimos los puntos
        int diagonal [] = new int [5];
    
        for (int i = 0; i<5; i++)
        {
            diagonal [i] = matrizJuego [i] [i];
        }
        int puntosDiagonal = puntos(diagonal);

        //Añadimos diagonal inversa y pedimos los puntos
        int diagonalInversa [] = new int [5];

        for (int i = 0; i<5; i++)
        {
            diagonalInversa [i] = matrizJuego [i] [4-i];
        }
        int puntosInversa = puntos(diagonalInversa);
   
        int puntuacionTotal = puntuacionFilas + puntuacionColumnas + puntosDiagonal + puntosInversa;
        return puntuacionTotal;
    }

    public static boolean matrizLLena(int mano[])
    {
        boolean llena = true;

        for(int i =0; i< mano.length; i++)
        {     
            if(mano[i]==0) //Miramos que ningun valor esté a 0
            {
                llena = false;
                break;
            }
        }
        return llena;
    }

   public static int puntos(int mano [])
    { 
        int RF = 0; //Escalera Real
        int SF = 0; //Escalera Color
        int K4 = 0; //Póquer
        int FH = 0; //Full House
        int FL = 0; //Color
        int STR = 0; //Escalera
        int K3 = 0; //Trío
        int PR2 = 0; //Dobles Parejas
        int PR1 = 0; //Pareja

        
        if(matrizLLena(mano))
        {
             if (escaleraReal(mano))
                {
                    RF = 2800;
                } 
                else
                {
                    if (escaleraColor(mano))
                    {
                        SF = 2400;
                    }
                    else
                    {
                        if (poker(mano))
                        {
                            K4 =2000;
                        }
                        else
                        {
                            if(full(mano))
                            {
                                FH = 1800;
                            }
                            else
                            {
                                if(color(mano))
                                {
                                    FL = 1400;
                                }
                                else
                                {
                                    if(escalera(mano))
                                    {
                                        STR = 1000;
                                    }
                                    else
                                    {
                                        if(trio(mano))
                                        {
                                            K3 = 800;
                                        }
                                        else
                                        {
                                            if(doblePareja(mano))
                                            {
                                                PR2 = 400;
                                            }
                                            else
                                            {
                                                if(pareja(mano))
                                                {
                                                    PR1 = 200;
                                                }
                                                else
                                                {
                                                    PR1 = 0;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
        }

        int total = RF + SF + K4 + FH + FL + STR + K3 + PR2 + PR1;

        return total;        
    }


    public static int[] valorCartas(int[] mano) 
    {
        //Guardamos el valor de las cartas de la mano con el módulo
        int[] valores = new int[mano.length];

        for (int i = 0; i < mano.length; i++) {
            valores[i] = mano[i] % 100;
        }

        return valores;
    }

    public static boolean hayAs (int []mano)
    {
        //Buscamos en nuestra mano si existe un as
        boolean flag = false;
        for(int i=0; i<mano.length;i++)
        {
            if(mano[i] % 100 == 1)//Sacamos el valor con el modulo
            {
                flag = true;
            }
        }

        return flag;
    }

    public static int [] cambioAs(int [] mano)
    {
        //Añadimos 13 al As (de valor 1) para que sea el mayor
        
        if(hayAs(mano))
        {
            for(int i = 0; i< mano.length; i++)
            {
                mano[i] = mano[i] + 13;
            }
        }

        return mano;
    }

    public static boolean mismoPalo(int[] mano) 
    {
        //Miramos si todas las cartas tienen el mismo palo

        int primerPalo = mano[0] / 100;//Comparar la primera carta con todas
        boolean flag = true;

        for (int i = 1; i < mano.length; i++)
        {
            int palo = mano[i] / 100; //Las centenas nos dicen que palo es
            if (palo != primerPalo)
            {
                flag = false;
                break;
            }
        }

        return flag;
    }

    public static boolean escaleraReal (int [] mano) 
    {
        boolean esReal = false; 
        
        int escaReal [] = valorCartas(mano); //pasamos a valores las cartas
        Arrays.sort(escaReal);

        if (mismoPalo(escaReal)) //Tiene todas el mismo palo
        {
            if (escaReal[0] == 1) //As
            {
                if (escaReal[1] == 10) //10
                {
                    if (escaReal[2] == 11) //J
                    {
                        if (escaReal[3] == 12) //Q
                        {
                            if (escaReal[4] == 13) //K
                            {
                                esReal = true;
                            }
                            else
                            {
                                esReal = false;
                            }
                        }
                        else
                        {
                            esReal = false;
                        }
                    }
                    else
                    {
                        esReal = false;
                    }
                }
                else 
                {
                    esReal= false;
                }
            }
            else
            {
                esReal = false;
            }
        }
        else 
        {
            esReal = false;
        }

        return esReal;
    }

    public static boolean escaleraColor (int [] mano)
    {
        //Cinco cartas consecutivas del mismo palo
        boolean flag = false;
        Arrays.sort(mano);

        if(mismoPalo(mano) && escalera(mano))
        {
            flag = true;
        }
        //Lo volvemos ha hacer pero con un as
        int []escColor = mano;
        if(hayAs(escColor))
        {
            escColor = cambioAs(escColor);
            if(mismoPalo(escColor) && escalera(escColor))
            {
                flag = true;   
            }
        }

        return flag;
    }

    public static boolean poker(int mano[])
    {
    //Miamos si tenemos 4 cartas iguaes
        boolean flag = false;
        int poker [] = valorCartas(mano);
        Arrays.sort(poker);

        if(poker[1] == poker[2] && poker[1] == poker[3] && poker[1] == poker[4] ||
        poker[0] == poker[1] && poker[0] == poker[2] && poker[0] == poker[3] )
        {
            flag = true;
        }

        return flag;
    }

    public static boolean full(int [] mano)
    { //Una pareja y un trio

        boolean flag = false;
        int[] full = valorCartas(mano);
        Arrays.sort(full);

        if(full[0] == full[1] && full [2] == full[3] && full[2] == full[4] ||//miramos si hay pareja y trio
         full[0] == full[1] && full [0] == full[2] && full[3] == full[4] ) //miramos si hay trio y luego pareja
        {
            flag = true;
        }

        return flag;
    }

    public static boolean color(int []mano)
    {
        //combinación de 5 cartas del mismo palo
        boolean flag = false;
        if(mismoPalo(mano))
        {
            flag=true;
        }
        return flag;
    }

    public static boolean escalera (int []mano)
    {
        //Miramos si los valores son consecutivos indepedientemente del palo

        int escalera[] = valorCartas (mano);
        Arrays.sort(escalera);
        boolean flag = true;

        for(int i=0; i< escalera.length-1;i++)
        {
            if(escalera[i] +1 != escalera[i+1])
            {
                flag = false;
                break;
            }
        }

        //Miramos si tiene un As, ponemos a true flag
        if(hayAs(escalera))
        {
            flag = true;
            int [] escaAs = cambioAs(escalera);
            mano = valorCartas(escaAs);
            Arrays.sort(escaAs);

            for(int i=0; i< escaAs.length-1;i++)//Miramos si son consecutivas
            {
                if(escaAs[i] +1 != escaAs[i+1])
                {
                    flag = false;
                    break;
                }
            }
        }

        return flag;
    }

    public static boolean trio(int mano[])
    {//Miamos si tenemos tres cartas iguales
            
        boolean flag = false;        
        int []trio = valorCartas(mano);
        Arrays.sort(trio);

        if (trio[0] ==trio[1] && trio[0] == trio[2] || 
            trio[1] ==trio[2] && trio[1] == trio[3] || 
            trio[2] ==trio[3] && trio[2] == trio[4] )
        {
            flag = true;
        }

        return flag;
    }

    public static boolean doblePareja(int[] mano) 
    {
        //miramos si hay una doble pareja

        boolean flag = false;
        int[] doblePareja = valorCartas(mano);
        Arrays.sort(doblePareja);

        if ((doblePareja[0] == doblePareja[1] && doblePareja[2] == doblePareja[3]) ||
            (doblePareja[0] == doblePareja[1] && doblePareja[3] == doblePareja[4]) ||
            (doblePareja[1] == doblePareja[2] && doblePareja[3] == doblePareja[4])) 
        {
            flag = true; 
        }

        return flag; // No se cumple la condición de doble pareja
    }


    public static boolean pareja(int mano[])
    {//Miamos si tenemos pareja

        boolean flag = false;

        if (mismaCarta(mano) ==1)//pareja
        {
            flag = true;
        }

        return flag;
    }

    public static int mismaCarta ( int mano [])
    {//miramos si los valores coinciden
        int cont=0;
        mano = valorCartas(mano);//Guardamos en un nuevo array solo los valores

        Arrays.sort(mano);

        for(int i=0; i<mano.length -1;i++)
        {
            if(mano[i] == mano[i + 1]){
                cont ++;
            }
        }

        return cont;
    }

}