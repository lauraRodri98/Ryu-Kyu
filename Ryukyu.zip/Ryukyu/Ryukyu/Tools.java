package Ryukyu;

import java.util.ArrayList;
import java.util.Scanner;

public class Tools {

    public static void limpiarPantalla() 
    {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static String calcularTiempo (long principio, long fin)
    {
        long tiempo = fin - principio;
        //Pasamos a segundos el tiempo y a minutos
        long segundos = tiempo / 1_000_000_000;
        long minutos = segundos / 60;
        segundos = segundos % 60;

        String tiempoFormateado = String.format("%d m %d s", minutos, segundos);

        return  tiempoFormateado;
    }
    
    public static void verRecords(ArrayList <Juego> records)
    {
        Scanner sc = new Scanner(System.in);

        int salir=-1;

        do{
            Tools.limpiarPantalla();

            System.out.println("                                            MEJORES JUGADAS     ");
            System.out.println("");                  
            System.out.println("                                         __ ");
            System.out.println("                                        |__|  \\|  |  |  |/  \\|  |  |");
            System.out.println("                                        | \\   /   |__|  |\\  /   |__|");
            System.out.println();                                          
            System.out.println("                                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");  
            System.out.println("                                     \u2661 " + " \u2660 " + " \u2663 " + " \u2662 " + " \u2661 " + " \u2660 " + " \u2663 " + " \u2662 " + " \u2663 " + " \u2662 " + " \u2661 " + " \u2660 ");      
            System.out.println("");                  
            System.out.println ("                           NOMBRE" + "      " + "FILAS" + "      " + "COLUMNAS" + "      " + "TIEMPO" +  "      " +"PUNTOS");
            System.out.println("                        ______________________________________________________________");
            System.out.println("");
            
            //Mostramos los datos guardados en nuestra lista
            if(records.size() > 0)
            {
                for (Juego j : records) 
                {
                    System.out.println(j.toString());
                }
            }
            System.out.println("                        _______________________________________________________________");

            System.out.println();
            System.out.println();
            System.out.println("                        Si desea volver al menú principal inserte 0");
            System.out.print("                        ");
            salir=sc.nextInt();
            Tools.limpiarPantalla();

        }while(salir != 0);
            
    }
}
