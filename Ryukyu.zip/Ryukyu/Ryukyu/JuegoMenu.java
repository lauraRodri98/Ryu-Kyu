package Ryukyu;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

class Juego {

    private String nombre;
    private int filas;
    private int columnas; 
    private String tiempo;
    private int puntuacion;

    Juego()
    {
        filas = 3;
        columnas = 3;
        nombre= "";
        tiempo=null;
        puntuacion =0;
    }

    Juego (String nombre, int filas, int columnas, String tiempo, int puntuacion)
    {
        this.nombre=nombre;
        this.filas = filas;
        this.columnas = columnas;
        this.tiempo = tiempo;
        this.puntuacion = puntuacion;
    }

    public int getFilas() {
        return filas;
    }

    public void setFilas(int filas) //-- mirar si filas son 4 en vez de 3
    {
        if(filas > 0 && filas < 5)
        {
            this.filas = filas;            
        }
        else{
            this.filas = 3;
        }
    }

    public int getColumnas() {
        return columnas;
    }

    public void setColumnas(int columnas) 
    {
        if(columnas > 0 && columnas < 5)
        {
            this.columnas = columnas;            
        }
        else{
            this.columnas = 3;
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTiempo() {
        return tiempo;
    }

    public void setTiempo(String tiempo) {
        this.tiempo = tiempo;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    @Override
    public String toString() 
    {

        return "                           "+ nombre + "         " + filas + "         " + columnas + "          " + tiempo + "        " + puntuacion ;
    }
}

class CompararTiempos implements Comparator<Juego>{
    @Override
    public int compare(Juego juego1, Juego juego2)
    {
        return juego1.getTiempo().compareTo(juego2.getTiempo());
    }
}

class compararFilasColumnas implements Comparator<Juego>{
        @Override
    public int compare(Juego juego1, Juego juego2)
    {
        //Si las filas y las columnas son iguales, lo ordenamos por tiempo
        CompararTiempos tiempo = new CompararTiempos();
        int comp=0;

        if(juego1.getColumnas() == juego2.getColumnas() && juego1.getFilas() == juego2.getFilas()){//Filas y columnas son iguale
            comp = tiempo.compare(juego1, juego2);
        }
        else if(juego1.getColumnas() == juego2.getColumnas()) //Si las columnas pero las filas no, lo ordenamos por filas
        {
            comp = (juego1.getFilas()-juego2.getFilas());
        }
        else if(juego1.getFilas() == juego2.getFilas())//Si las filas son iguales pero las columnas no lo ordenamos por columnas
        {
            comp = (juego1.getColumnas()-juego2.getColumnas());
        }
        else{ 
            comp = juego1.getFilas() - juego2.getFilas();//si no es ninguna igual lo ordenamos por filas
        }

        return comp;
    }
}

public class JuegoMenu
{

    public static void main(String[] args) 
    {
        //Creamos dos variables, para jugadas (contador de cuantas jugadas llevamos) y juegoNuevo (Si el usuario desea volver a jugar)

        Scanner sc= new Scanner(System.in);  

        int filas = 3;
        int columnas = 3;
        String nombre =""; 
        int opcion; 
        //Inicializamos los tiempos



        ArrayList<Juego> añadirJugada = new ArrayList<>(); //lista que nos añade los datos a los Records

        Juego juego = new Juego ();

        do {
            System.out.println("                               __ ");
            System.out.println("                              |__|  \\|  |  |  |/  \\|  |  |");
            System.out.println("                              | \\   /   |__|  |\\  /   |__|");
            System.out.println();                                
            System.out.println("                                 DIFICULTAD DEL JUEGO");
            System.out.println("                                 Filas: " + filas + " Columnas: " + columnas  );     
            System.out.println("                          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");      
            System.out.println("                          \u2661 " + " \u2660 " + " \u2663 " + " \u2662 " + " \u2661 " + " \u2660 " + " \u2663 " + " \u2662 " + " \u2663 " + " \u2662 " + " \u2661 " + " \u2660 ");      
            System.out.println("                            1 - Empezar juego             ");
            System.out.println("                            2 - Indique numero de filas   ");
            System.out.println("                            3 - Indique numero de columnas");
            System.out.println("                            4 - Mostrar Récords           ");
            System.out.println("                            5 - Salir                     ");
            System.out.print("                            Elija una opción:   ");
            opcion = sc.nextInt();
            
            switch (opcion)
            {
                case 1: 
                    //Pedimos nombre para insertarlo a los Records más tarde
                    System.out.print("                            Nombre: ");
                    nombre = sc.next();
                    long principio =0;
                    long fin=0;
                    String tiempo ="";

                    //Empieza el tiempo y el juego
                    principio = System.nanoTime();
                    IniciarJuego.Ryukyu(filas, columnas); 
                    fin = System.nanoTime();

                    //Añadimos los datos a la lista para luego mostrarlo por los records
                    tiempo = Tools.calcularTiempo(principio, fin); 
                    //Leemos la puntuacion del archivo
                    BufferedReader in = null;
                    Integer puntuacion=0;
                    try 
                    {
                        in = new BufferedReader(new FileReader("out.txt"));
                        String leer = in.readLine();
                        puntuacion = Integer.valueOf(leer);
                        
                    } catch (Exception e) {
                        System.out.println("No se ha leido correctamente");
                    }
                    añadirJugada.add (new Juego(nombre, filas, columnas, tiempo, puntuacion));
                    añadirJugada.sort(new compararFilasColumnas()); //Ordenamos en funcion del tiempo y dificultad
                    Tools.verRecords(añadirJugada);
                    Tools.limpiarPantalla();
                    break;

                case 2: 
                    System.out.println("                            Filas -> [1 - 3] ");
                    System.out.print("                            ");
                    filas = sc.nextInt();
                    juego.setFilas(filas);
                    Tools.limpiarPantalla();
                    break;

                case 3:
                    System.out.println("                            Número de columnas -> [1 - 4] ");
                    System.out.print("                            ");
                    columnas = sc.nextInt();
                    juego.setColumnas(columnas);
                    Tools.limpiarPantalla();
                    break;

                case 4:
                    Tools.verRecords(añadirJugada);
                    break;

                case 5:
                    System.out.println("                            Hasta luego! ");
                    break;

                default:      
                    System.out.println("                             Opción inválida");
            } 

        } while (opcion != 5);//Si no queremos vover a jugar, mostraremos los resultados de los Records
        sc.close();
    }
}